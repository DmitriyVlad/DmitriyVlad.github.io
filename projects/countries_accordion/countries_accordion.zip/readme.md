### To install required modules type `yarn install.`

### To run local server type `gulp` in project folder.
